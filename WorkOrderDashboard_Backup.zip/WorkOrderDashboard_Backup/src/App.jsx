import React, { useState, useEffect, useRef } from 'react';
import * as XLSX from 'xlsx';
import KPICard from './components/KPICard';
import DataTable from './components/DataTable';
import JobDetailsModal from './components/JobDetailsModal';
import MonthDetailsModal from './components/MonthDetailsModal';
import './App.css';
import { FileUp } from 'lucide-react';

function App() {
  const [metrics, setMetrics] = useState({
    operationalErrors: 0,
    partsConsumed: 0,
    partsValue: 0,
    totalCorrective: 0,
    totalPlanned: 0,
    totalRemedial: 0
  });
  const [rawData, setRawData] = useState([]);
  const [lastUpdated, setLastUpdated] = useState(null);
  const [selectedKpi, setSelectedKpi] = useState(null);
  const [filteredData, setFilteredData] = useState([]);
  const [tableTitle, setTableTitle] = useState('');
  const [selectedJob, setSelectedJob] = useState(null);
  const [groupByMonth, setGroupByMonth] = useState(false);
  const [isRolledUp, setIsRolledUp] = useState(false);
  const [selectedMonthData, setSelectedMonthData] = useState(null); // { name: 'December 2024', jobs: [] }

  const tableRef = useRef(null);

  // Helper to parse Excel dates (handles serial numbers and strings)
  const parseExcelDate = (value) => {
    if (!value) return null;
    // Excel serial date (e.g. 45678)
    if (typeof value === 'number') {
      // Excel base date is Dec 30 1899
      return new Date(Math.round((value - 25569.15) * 86400 * 1000));
    }
    // String date
    const d = new Date(value);
    return isNaN(d.getTime()) ? null : d;
  };

  const getMonthName = (date) => {
    if (!date) return 'Unknown Date';
    return date.toLocaleString('default', { month: 'long', year: 'numeric' });
  };

  // Scroll to table when filtered data changes
  useEffect(() => {
    if (selectedKpi && tableRef.current) {
      tableRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [selectedKpi]);

  const handleFileUpload = (e) => {
    const file = e.target.files[0];
    if (file) processFile(file);
  };

  const handleDrop = (e) => {
    e.preventDefault();
    const file = e.dataTransfer.files[0];
    if (file) processFile(file);
  };

  const processFile = (file) => {
    const reader = new FileReader();
    reader.onload = (evt) => {
      const bstr = evt.target.result;
      const wb = XLSX.read(bstr, { type: 'binary' });
      const wsname = wb.SheetNames[0];
      const ws = wb.Sheets[wsname];
      const data = XLSX.utils.sheet_to_json(ws);

      // Parse dates immediately
      const processedData = data.map(row => ({
        ...row,
        ParsedDate: parseExcelDate(row.StartedAt) // Store parsed date object
      }));

      setRawData(processedData);
      calculateMetrics(processedData);
      setLastUpdated(new Date().toLocaleString());
      // Reset selection
      setSelectedKpi(null);
      setFilteredData([]);
    };
    reader.readAsBinaryString(file);
  };

  const calculateMetrics = (data) => {
    let stats = {
      operationalErrors: 0,
      partsConsumed: 0,
      partsValue: 0,
      totalCorrective: 0,
      totalPlanned: 0,
      totalRemedial: 0
    };

    data.forEach(row => {
      if (row['IsOperational'] == 1) stats.operationalErrors++;
      stats.partsConsumed += Number(row['Part Count'] || 0);
      stats.partsValue += Number(row['Part Cost'] || 0);
      if (row['Type'] === 'Corrective Maintenance') stats.totalCorrective++;
      if (row['Type'] === 'Preventive Maintenance') stats.totalPlanned++;
      if (row['Type'] === 'Remedial Task') stats.totalRemedial++;
    });

    setMetrics(stats);
  };

  const handleKpiClick = (kpiKey, title) => {
    if (selectedKpi === kpiKey) {
      setSelectedKpi(null);
      setFilteredData([]);
      return;
    }

    setSelectedKpi(kpiKey);
    setTableTitle(title);

    let filtered = [];
    switch (kpiKey) {
      case 'operationalErrors':
        filtered = rawData.filter(r => r['IsOperational'] == 1);
        break;
      case 'partsConsumed':
      case 'partsValue':
        // Show rows that have parts
        filtered = rawData.filter(r => Number(r['Part Count']) > 0 || Number(r['Part Cost']) > 0);
        break;
      case 'totalCorrective':
        filtered = rawData.filter(r => r['Type'] === 'Corrective Maintenance');
        break;
      case 'totalPlanned':
        filtered = rawData.filter(r => r['Type'] === 'Preventive Maintenance');
        break;
      case 'totalRemedial':
        filtered = rawData.filter(r => r['Type'] === 'Remedial Task');
        break;
      default:
        filtered = [];
    }
    setFilteredData(filtered);
  };

  return (
    <div className="dashboard-container" onDragOver={(e) => e.preventDefault()} onDrop={handleDrop}>
      <header className="dashboard-header">
        <div>
          <h1>Operations Dashboard</h1>
          <p>Real-time insights from work orders</p>
        </div>
        <div className="header-actions">
          {filteredData.length > 0 && (
            <div style={{ display: 'flex', gap: '8px' }}>
              <button
                onClick={() => {
                  setGroupByMonth(!groupByMonth);
                  setIsRolledUp(false); // Reset rollup when toggling mode
                }}
                className={`group-btn ${groupByMonth ? 'active' : ''}`}
              >
                {groupByMonth ? 'Ungroup' : 'Group by Month'}
              </button>

              {groupByMonth && (
                <button
                  onClick={() => setIsRolledUp(!isRolledUp)}
                  className={`group-btn ${isRolledUp ? 'active' : ''}`}
                >
                  {isRolledUp ? 'Expand All' : 'Rollup'}
                </button>
              )}
            </div>
          )}
          {lastUpdated && <span className="last-updated">Updated: {lastUpdated}</span>}
          <label className="upload-drop-zone">
            <div className="drop-content">
              <FileUp size={20} className="drop-icon" />
              <span>Drag & Drop or Click to Upload</span>
            </div>
            <input type="file" accept=".xlsx, .xls" onChange={handleFileUpload} hidden />
          </label>
        </div>
      </header>

      <div className="kpi-grid">
        <KPICard
          title="Operational Errors"
          value={metrics.operationalErrors}
          subtext="Total errors this period"
          ringColor="#ef4444"
          alert={metrics.operationalErrors > 0}
          onClick={() => handleKpiClick('operationalErrors', 'Operational Errors')}
          isSelected={selectedKpi === 'operationalErrors'}
        />
        <KPICard
          title="Parts Consumed"
          value={metrics.partsConsumed}
          subtext="Total parts used"
          ringColor="#3b82f6"
          onClick={() => handleKpiClick('partsConsumed', 'Parts Consumed')}
          isSelected={selectedKpi === 'partsConsumed'}
        />
        <KPICard
          title="Parts Value Total"
          value={`£${metrics.partsValue.toFixed(2)}`}
          subtext="Total cost of parts"
          ringColor="#eab308"
          onClick={() => handleKpiClick('partsValue', 'Parts Value')}
          isSelected={selectedKpi === 'partsValue'}
        />
        <KPICard
          title="Total Corrective"
          value={metrics.totalCorrective}
          subtext="Unplanned maintenance"
          ringColor="#f97316"
          onClick={() => handleKpiClick('totalCorrective', 'Corrective Maintenance Tasks')}
          isSelected={selectedKpi === 'totalCorrective'}
        />
        <KPICard
          title="Total Planned"
          value={metrics.totalPlanned}
          subtext="Scheduled maintenance"
          ringColor="#22c55e"
          onClick={() => handleKpiClick('totalPlanned', 'Planned Maintenance Tasks')}
          isSelected={selectedKpi === 'totalPlanned'}
        />
        <KPICard
          title="Total Remedial"
          value={metrics.totalRemedial}
          subtext="Remedial tasks"
          ringColor="#a855f7"
          onClick={() => handleKpiClick('totalRemedial', 'Remedial Tasks')}
          isSelected={selectedKpi === 'totalRemedial'}
        />
      </div>

      {selectedKpi && (
        <div id="data-table-section" style={{ marginTop: '2rem' }} ref={tableRef}>
          <DataTable
            data={filteredData}
            title={tableTitle}
            onJobClick={(job) => setSelectedJob(job)}
            groupBy={groupByMonth}
            isRolledUp={isRolledUp}
            onMonthAnalyze={(jobs, monthName) => setSelectedMonthData({ jobs, name: monthName })}
          />
        </div>
      )}

      {selectedJob && (
        <JobDetailsModal
          job={selectedJob}
          onClose={() => setSelectedJob(null)}
        />
      )}

      {selectedMonthData && (
        <MonthDetailsModal
          monthName={selectedMonthData.name}
          jobs={selectedMonthData.jobs}
          onClose={() => setSelectedMonthData(null)}
        />
      )}
    </div>
  );
}

export default App;
