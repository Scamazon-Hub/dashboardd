import React, { useMemo } from 'react';
import { PieChart, Pie, Cell, Tooltip, Legend } from 'recharts';
import { X, Wrench, TrendingUp, AlertTriangle, DollarSign } from 'lucide-react';
import './JobDetailsModal.css';

const COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899'];

const MonthDetailsModal = ({ monthName, jobs, onClose }) => {

    // 1. Calculate Summaries
    const stats = useMemo(() => {
        let totalCost = 0;
        let totalParts = 0;
        let breakdown = { corrective: 0, preventive: 0, remedial: 0 };

        if (!jobs) return { totalCost: 0, totalParts: 0, breakdown };

        jobs.forEach(j => {
            // Safe number parsing
            const cost = parseFloat(j['Part Cost']);
            totalCost += isNaN(cost) ? 0 : cost;

            const count = parseFloat(j['Part Count']);
            totalParts += isNaN(count) ? 0 : count;

            const type = j.Type || 'Other';
            if (type.includes('Corrective')) breakdown.corrective++;
            else if (type.includes('Preventive')) breakdown.preventive++;
            else if (type.includes('Remedial')) breakdown.remedial++;
        });

        return { totalCost, totalParts, breakdown };
    }, [jobs]);

    // 2. Prepare Asset Chart Data
    const assetData = useMemo(() => {
        if (!jobs) return [];
        const counts = {};
        jobs.forEach(j => {
            const asset = j.Asset || 'Unknown';
            counts[asset] = (counts[asset] || 0) + 1;
        });

        return Object.entries(counts)
            .map(([name, value]) => ({ name, value }))
            .sort((a, b) => b.value - a.value)
            .slice(0, 8); // Top 8 assets
    }, [jobs]);

    return (
        <div className="modal-overlay" onClick={onClose}>
            <div className="modal-content" onClick={e => e.stopPropagation()} style={{ maxWidth: '1000px' }}>

                {/* Header */}
                <div className="modal-header">
                    <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
                        <h2>Analysis: {monthName}</h2>
                        <span className="status-badge complete">{jobs ? jobs.length : 0} Jobs Total</span>
                    </div>
                    <button className="close-btn" onClick={onClose}><X size={24} /></button>
                </div>

                {/* Body */}
                <div className="modal-body" style={{ padding: '2rem' }}>

                    {/* KPI Cards Row */}
                    <div style={{
                        display: 'grid',
                        gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
                        gap: '1rem',
                        marginBottom: '2rem'
                    }}>
                        <div className="kpi-mini-card">
                            <div className="icon" style={{ color: '#ef4444' }}><AlertTriangle size={20} /></div>
                            <div>
                                <div className="label">Corrective</div>
                                <div className="val">{stats.breakdown.corrective}</div>
                            </div>
                        </div>
                        <div className="kpi-mini-card">
                            <div className="icon" style={{ color: '#10b981' }}><Wrench size={20} /></div>
                            <div>
                                <div className="label">Planned</div>
                                <div className="val">{stats.breakdown.preventive}</div>
                            </div>
                        </div>
                        <div className="kpi-mini-card">
                            <div className="icon" style={{ color: '#3b82f6' }}><TrendingUp size={20} /></div>
                            <div>
                                <div className="label">Parts Used</div>
                                <div className="val">{stats.totalParts}</div>
                            </div>
                        </div>
                        <div className="kpi-mini-card">
                            <div className="icon" style={{ color: '#f59e0b' }}><DollarSign size={20} /></div>
                            <div>
                                <div className="label">Part Cost</div>
                                <div className="val">£{stats.totalCost.toFixed(2)}</div>
                            </div>
                        </div>
                    </div>

                    {/* Charts Section */}
                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '2rem' }}>

                        {/* 1. Asset Breakdown (Pie) */}
                        <div className="chart-container" style={{ height: '320px', background: '#f8fafc', padding: '1rem', borderRadius: '12px', display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                            <h3 style={{ marginTop: 0, color: '#475569', fontSize: '1rem', alignSelf: 'flex-start' }}>Top Assets by Volume</h3>
                            {/* Fixed dimensions to avoid rendering issues in modal */}
                            <div style={{ flex: 1, width: '100%', display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
                                {assetData.length > 0 ? (
                                    <PieChart width={300} height={250}>
                                        <Pie
                                            data={assetData}
                                            cx="50%"
                                            cy="50%"
                                            innerRadius={60}
                                            outerRadius={80}
                                            paddingAngle={5}
                                            dataKey="value"
                                        >
                                            {assetData.map((entry, index) => (
                                                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                                            ))}
                                        </Pie>
                                        <Tooltip />
                                        <Legend verticalAlign="bottom" height={36} />
                                    </PieChart>
                                ) : (
                                    <div style={{ color: '#94a3b8' }}>No data available</div>
                                )}
                            </div>
                        </div>

                        {/* 2. Top Issues List */}
                        <div className="chart-container" style={{ height: '320px', background: '#f8fafc', padding: '1rem', borderRadius: '12px', overflowY: 'auto' }}>
                            <h3 style={{ marginTop: 0, color: '#475569', fontSize: '1rem' }}>Recent Issues</h3>
                            <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                                {jobs && jobs.slice(0, 50).map((j, i) => (
                                    <div key={i} style={{
                                        background: 'white',
                                        padding: '8px 12px',
                                        borderRadius: '6px',
                                        border: '1px solid #e2e8f0',
                                        fontSize: '0.85rem',
                                        color: '#334155',
                                        display: 'flex',
                                        justifyContent: 'space-between'
                                    }}>
                                        <span style={{ fontWeight: 500 }}>{j.Asset}</span>
                                        <span style={{ color: '#64748b', fontSize: '0.75rem' }}>{j.Type}</span>
                                    </div>
                                ))}
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    );
};

export default MonthDetailsModal;

// Add this CSS to App.css or JobDetailsModal.css
/*
.kpi-mini-card {
    background: white;
    padding: 1rem;
    border-radius: 12px;
    border: 1px solid #e2e8f0;
    display: flex;
    align-items: center;
    gap: 1rem;
    box-shadow: 0 1px 2px rgba(0,0,0,0.05);
}
.kpi-mini-card .label { font-size: 0.8rem; color: #64748b; font-weight: 500; }
.kpi-mini-card .val { font-size: 1.5rem; color: #0f172a; font-weight: 700; }
*/
