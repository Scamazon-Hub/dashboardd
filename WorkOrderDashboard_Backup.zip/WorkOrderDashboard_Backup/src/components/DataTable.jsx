import React, { useState, useMemo, useEffect } from 'react';
import './DataTable.css';
import { ArrowUpDown, ArrowUp, ArrowDown, ChevronDown, ChevronRight, PieChart } from 'lucide-react';

const DataTable = ({ data, title, onJobClick, groupBy, isRolledUp, onMonthAnalyze }) => {
    const [sortConfig, setSortConfig] = useState({ key: null, direction: 'ascending' });
    const [expandedGroups, setExpandedGroups] = useState(new Set());

    if (!data || data.length === 0) return null;

    // Helper for grouping
    const getMonthGroup = (dateObj) => {
        if (!dateObj) return 'Unknown Date';
        const date = typeof dateObj === 'string' ? new Date(dateObj) : dateObj;
        if (isNaN(date.getTime())) return 'Invalid Date';
        return date.toLocaleString('default', { month: 'long', year: 'numeric' });
    };

    const sortedData = useMemo(() => {
        let items = [...data];
        if (sortConfig.key !== null) {
            items.sort((a, b) => {
                let aValue = a[sortConfig.key];
                let bValue = b[sortConfig.key];

                if (sortConfig.key === 'Work Order') {
                    aValue = a.Id || a['Work Order'] || '';
                    bValue = b.Id || b['Work Order'] || '';
                } else if (sortConfig.key === 'Engineer') {
                    aValue = a['Technicians'] || a['Technician Total'] || '';
                    bValue = b['Technicians'] || b['Technician Total'] || '';
                } else if (sortConfig.key === 'Part Quantity') {
                    aValue = Number(a['Part Count'] || 0);
                    bValue = Number(b['Part Count'] || 0);
                } else if (sortConfig.key === 'Details') {
                    aValue = a.Comment || a['Cause Text'] || '';
                    bValue = b.Comment || b['Cause Text'] || '';
                } else {
                    aValue = a[sortConfig.key] || '';
                    bValue = b[sortConfig.key] || '';
                }

                if (aValue < bValue) return sortConfig.direction === 'ascending' ? -1 : 1;
                if (aValue > bValue) return sortConfig.direction === 'ascending' ? 1 : -1;
                return 0;
            });
        }
        return items;
    }, [data, sortConfig]);

    const groupedData = useMemo(() => {
        if (!groupBy) return { 'All': sortedData };

        return sortedData.reduce((acc, row) => {
            const groupName = getMonthGroup(row.ParsedDate);
            if (!acc[groupName]) acc[groupName] = [];
            acc[groupName].push(row);
            return acc;
        }, {});
    }, [sortedData, groupBy]);

    // Manage Expansion Effect
    useEffect(() => {
        if (!groupBy) return;

        const allKeys = Object.keys(groupedData);
        if (isRolledUp) {
            setExpandedGroups(new Set()); // Collapse all
        } else {
            setExpandedGroups(new Set(allKeys)); // Expand all
        }
    }, [isRolledUp, groupBy, groupedData]);

    const toggleGroup = (group) => {
        const newSet = new Set(expandedGroups);
        if (newSet.has(group)) {
            newSet.delete(group);
        } else {
            newSet.add(group);
        }
        setExpandedGroups(newSet);
    };

    const requestSort = (key) => {
        let direction = 'ascending';
        if (sortConfig.key === key && sortConfig.direction === 'ascending') {
            direction = 'descending';
        }
        setSortConfig({ key, direction });
    };

    const getSortIcon = (name) => {
        if (sortConfig.key !== name) return <ArrowUpDown size={14} style={{ marginLeft: '5px', opacity: 0.3 }} />;
        if (sortConfig.direction === 'ascending') return <ArrowUp size={14} style={{ marginLeft: '5px' }} />;
        return <ArrowDown size={14} style={{ marginLeft: '5px' }} />;
    };

    return (
        <div className="table-container">
            <div className="table-header">
                <h2>{title}</h2>
            </div>
            <div style={{ overflowX: 'auto' }}>
                <table className="data-table">
                    <thead>
                        <tr>
                            <th onClick={() => requestSort('Work Order')}>Work Order {getSortIcon('Work Order')}</th>
                            <th onClick={() => requestSort('Asset')}>Asset {getSortIcon('Asset')}</th>
                            <th onClick={() => requestSort('Type')}>Type {getSortIcon('Type')}</th>
                            <th onClick={() => requestSort('Engineer')}>Engineer {getSortIcon('Engineer')}</th>
                            <th onClick={() => requestSort('Part Quantity')}>Part Quantity {getSortIcon('Part Quantity')}</th>
                            <th onClick={() => requestSort('Status')}>Status {getSortIcon('Status')}</th>
                            <th onClick={() => requestSort('Details')}>Details {getSortIcon('Details')}</th>
                        </tr>
                    </thead>
                    {Object.entries(groupedData).map(([group, rows]) => {
                        const isExpanded = groupBy ? expandedGroups.has(group) : true;

                        return (
                            <React.Fragment key={group}>
                                {groupBy && (
                                    <thead style={{ cursor: 'pointer' }} onClick={() => toggleGroup(group)}>
                                        <tr className="group-header">
                                            <th colSpan="7" style={{ backgroundColor: '#f1f5f9', color: '#334155', fontSize: '0.9rem', borderTop: '1px solid #e2e8f0' }}>
                                                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                                                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                                                        {isExpanded ? <ChevronDown size={16} /> : <ChevronRight size={16} />}
                                                        {group}
                                                        <span style={{ fontWeight: 'normal', color: '#64748b', marginLeft: '8px' }}>
                                                            ({rows.length} jobs)
                                                        </span>
                                                    </div>

                                                    {/* Analyze Button */}
                                                    <button
                                                        className="analyze-btn"
                                                        onClick={(e) => {
                                                            e.stopPropagation();
                                                            onMonthAnalyze && onMonthAnalyze(rows, group);
                                                        }}
                                                    >
                                                        <PieChart size={14} /> Analyze Month
                                                    </button>
                                                </div>
                                            </th>
                                        </tr>
                                    </thead>
                                )}
                                {isExpanded && (
                                    <tbody>
                                        {rows.map((row, index) => (
                                            <tr key={index} onClick={() => onJobClick && onJobClick(row)} style={{ cursor: 'pointer' }}>
                                                <td style={{ fontWeight: 'bold', color: '#2563eb' }}>
                                                    #{row.Id || row['Work Order'] || 'N/A'}
                                                </td>
                                                <td>{row.Asset || 'N/A'}</td>
                                                <td>{row.Type || 'N/A'}</td>
                                                <td>{row['Technicians'] || row['Technician Total'] || 'Unknown'}</td>
                                                <td>{row['Part Count'] || 0}</td>
                                                <td>
                                                    <span className={`status-badge ${row.Status === 'Complete' ? 'complete' : 'open'}`}>
                                                        {row.Status || 'Unknown'}
                                                    </span>
                                                </td>
                                                <td style={{ maxWidth: '200px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                                                    {row.Comment || row['Cause Text'] || '-'}
                                                </td>
                                            </tr>
                                        ))}
                                    </tbody>
                                )}
                            </React.Fragment>
                        )
                    })}
                </table>
            </div>
        </div>
    );
};

export default DataTable;
