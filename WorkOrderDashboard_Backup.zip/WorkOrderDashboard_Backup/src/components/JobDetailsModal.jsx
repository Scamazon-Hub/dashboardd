
import React from 'react';
import './JobDetailsModal.css';
import { ExternalLink, X } from 'lucide-react';

const JobDetailsModal = ({ job, onClose }) => {
    if (!job) return null;

    const rawId = job.Id || job['Work Order'];
    // Ensure we strip any # if accidentally included in source, though usually raw is clean.
    // Assuming rawId is just the number like 12733896
    const externalLink = `https://css.ssi-schaefer.com/sm/workorder/?workorderId=${rawId}`;

    return (
        <div className="modal-overlay" onClick={onClose}>
            <div className="modal-content" onClick={(e) => e.stopPropagation()}>
                <div className="modal-header">
                    <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
                        <h2>Work Order #{rawId}</h2>
                        <span className={`status-badge ${job.Status === 'Complete' ? 'complete' : 'open'}`}>
                            {job.Status || 'Unknown'}
                        </span>
                    </div>
                    <button className="close-btn" onClick={onClose}>
                        <X size={24} />
                    </button>
                </div>

                <div className="modal-body">
                    <div className="job-meta-grid">
                        <div className="meta-item">
                            <label>Asset</label>
                            <div className="value">{job.Asset || 'N/A'}</div>
                        </div>
                        <div className="meta-item">
                            <label>Engineer</label>
                            <div className="value">{job['Technicians'] || job['Technician Total'] || 'Unknown'}</div>
                        </div>
                        <div className="meta-item">
                            <label>Type</label>
                            <div className="value">{job.Type || 'N/A'}</div>
                        </div>
                        <div className="meta-item">
                            <label>Parts Count</label>
                            <div className="value">{job['Part Count'] || 0}</div>
                        </div>
                    </div>

                    <div className="job-description">
                        <h3>Full Description / Cause</h3>
                        <p>{job.Comment || job['Cause Text'] || 'No details provided.'}</p>
                    </div>

                    <div className="modal-actions">
                        <a
                            href={externalLink}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="external-link-btn"
                        >
                            <ExternalLink size={16} /> Open in SSI Schaefer
                        </a>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default JobDetailsModal;
