import React from 'react';
import './KPICard.css';

const KPICard = ({ title, value, subtext, ringColor = '#3b82f6', icon, alert, onClick, isSelected }) => {
  return (
    <div
      className={`kpi-card ${isSelected ? 'selected' : ''}`}
      onClick={onClick}
      style={{ '--ring-color': ringColor }}
    >
      <div className="kpi-header">
        <span className="kpi-title">{title}</span>
        {icon && <span className="kpi-icon" style={{ color: ringColor }}>{icon}</span>}
        {alert && <span className="kpi-alert">⚠️</span>}
      </div>

      <div className="kpi-body">
        <div className="kpi-content">
          <div className="kpi-value">{value}</div>
          <div className="kpi-subtext">{subtext}</div>
        </div>

        <div className="kpi-ring-container">
          <div className="breathing-ring" style={{ '--ring-color': ringColor }}></div>
        </div>
      </div>
    </div>
  );
};

export default KPICard;

